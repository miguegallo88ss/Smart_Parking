#ifndef internetVars_h
#define internetVars_h

#include <SPI.h>
#include <Ethernet.h>

    //Internet Setup







#endif
